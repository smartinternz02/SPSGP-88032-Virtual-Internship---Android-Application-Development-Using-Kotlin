package com.example.project2groceryapp
import android.content.ClipData
import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.Dao


import kotlinx.coroutines.flow.Flow

@Dao
interface Dao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: GroceryItems)

    @Delete
    suspend fun delete(item : GroceryItems)


    @Query("SELECT * FROM grocery_items ")
    fun getItems(): LiveData<List<GroceryItems>>
    @Query("SELECT *FROM grocery_items WHERE Name LIKE :searchQuery")
    fun searchDatabase(searchQuery: String) : LiveData<List<GroceryItems>>





}