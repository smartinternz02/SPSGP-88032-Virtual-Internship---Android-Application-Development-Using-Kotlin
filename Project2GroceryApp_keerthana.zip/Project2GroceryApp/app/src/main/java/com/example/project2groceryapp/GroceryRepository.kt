package com.example.project2groceryapp

import androidx.lifecycle.LiveData
import androidx.room.Database
import androidx.room.Query
import com.example.project2groceryapp.GroceryDatabase
import com.example.project2groceryapp.GroceryItems

class GroceryRepository(private val db : GroceryDatabase) {
    suspend fun insert(items: GroceryItems) = db.getGroceryDoa().insert(items)
    suspend fun delete(items: GroceryItems) = db.getGroceryDoa().delete(items)

    fun searchDatabase(searchQuery: String):LiveData<List<GroceryItems>> {
        return db.getGroceryDoa().searchDatabase(searchQuery)
    }



    fun getAllItems() = db.getGroceryDoa().getItems()
}